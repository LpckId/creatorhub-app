package com.example.data.linkguard

import android.net.Uri
import com.example.data.model.LinkReport
import com.example.data.model.RiskLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URL
import java.util.concurrent.TimeUnit

object LinkAnalyzer {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(false) // We want to trace hops manually
            .followSslRedirects(false)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    private val JUDOL_KEYWORDS = setOf(
        "slot", "gacor", "judol", "judi", "togel", "maxwin", "pragmatic", "zeus",
        "olympus", "depo", "wd", "taruhan", "casino", "poker", "sbobet", "rtp",
        "scatter", "jackpot", "hoki", "sensational", "bandar", "link alternatif",
        "agen slot", "mahjong", "starlight", "habanero", "spadegaming", "deposit pulsa",
        "bonus new member", "freebet", "turnover", "anti rungkad", "daftar slot",
        "toto", "live casino", "baccarat", "roulette", "sweet bonanza", "gates of olympus"
    )

    private val PHISHING_KEYWORDS = setOf(
        "dana kaget", "bansos", "hadiah", "undian", "pulsa gratis", "klaim",
        "menang undian", "verifikasi whatsapp", "login facebook", "otp", "bca mobile",
        "bri ceria", "briva", "blt", "prakerja", "kuota gratis", "subsidi", "tebus murah",
        "undian telkomsel", "gebyar bca", "klaim saldo", "undian bri", "kartu kredit",
        "phishing", "update akun", "blokir rekening"
    )

    private val POPUP_AD_NETWORKS = setOf(
        "adsterra", "monetag", "propellerads", "hilltopads", "popads", "popcash",
        "clickadu", "exoclick", "richads", "trafficstars", "adcash", "yepads"
    )

    private val TRACKING_PARAMS = setOf(
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "fbclid", "gclid", "ttclid", "aff_id", "sub_id", "click_id", "ref",
        "affiliate_id", "sp_atk", "xptdk", "universal_link", "campaign_id",
        "ad_id", "placement", "tracking_code"
    )

    suspend fun analyzeUrl(inputUrl: String): LinkReport = withContext(Dispatchers.IO) {
        var formattedUrl = inputUrl.trim()
        if (!formattedUrl.startsWith("http://") && !formattedUrl.startsWith("https://")) {
            formattedUrl = "https://$formattedUrl"
        }

        val hops = mutableListOf<String>()
        hops.add(formattedUrl)

        var currentUrl = formattedUrl
        var finalUrl = formattedUrl
        var loopCount = 0
        val maxHops = 6

        // Trace HTTP redirect chain
        try {
            while (loopCount < maxHops) {
                loopCount++
                val request = Request.Builder()
                    .url(currentUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")
                    .build()

                val response = httpClient.newCall(request).execute()
                val code = response.code
                val location = response.header("Location")

                if (code in 300..399 && !location.isNullOrBlank()) {
                    var nextUrl = location
                    if (nextUrl.startsWith("/")) {
                        val base = URL(currentUrl)
                        nextUrl = "${base.protocol}://${base.host}$nextUrl"
                    }
                    hops.add(nextUrl)
                    currentUrl = nextUrl
                    finalUrl = nextUrl
                } else {
                    finalUrl = currentUrl
                    break
                }
            }
        } catch (e: Exception) {
            // If network failed, analyze using current known URL and heuristics
            finalUrl = currentUrl
        }

        // Parse domain & structure
        val uri = try { Uri.parse(finalUrl) } catch (e: Exception) { Uri.parse(formattedUrl) }
        val domain = uri.host?.lowercase() ?: "unknown"
        val isSsl = finalUrl.startsWith("https://")

        // Check for Tracking parameters
        val trackingFound = mutableMapOf<String, String>()
        try {
            uri.queryParameterNames?.forEach { paramName ->
                if (TRACKING_PARAMS.contains(paramName.lowercase())) {
                    val value = uri.getQueryParameter(paramName) ?: ""
                    trackingFound[paramName] = value
                }
            }
        } catch (e: Exception) {
            // ignore query parse issues
        }

        // Cleaned URL without tracking query parameters
        val cleanedUrl = buildCleanUrl(finalUrl)

        // Evaluate Keywords in entire redirect chain and URL
        val allTextToCheck = (hops.joinToString(" ") + " " + finalUrl).lowercase()
        val detectedJudol = JUDOL_KEYWORDS.filter { allTextToCheck.contains(it) }
        val detectedPhishing = PHISHING_KEYWORDS.filter { allTextToCheck.contains(it) }
        val detectedAdNetwork = POPUP_AD_NETWORKS.filter { allTextToCheck.contains(it) }

        // E-Commerce Identification
        val isShopee = domain.contains("shopee") || domain.contains("shp.ee")
        val isTokopedia = domain.contains("tokopedia") || domain.contains("tokopedia.link")
        val isLazada = domain.contains("lazada") || domain.contains("s.lazada")
        val isTikTokShop = domain.contains("tiktok.com") && (domain.contains("shop") || allTextToCheck.contains("product"))

        val eComType = when {
            isShopee && trackingFound.isNotEmpty() -> "Shopee Affiliate Link"
            isShopee -> "Shopee Official Link"
            isTokopedia && trackingFound.isNotEmpty() -> "Tokopedia Affiliate / Promo Link"
            isTokopedia -> "Tokopedia Official Link"
            isLazada -> "Lazada Affiliate Link"
            isTikTokShop -> "TikTok Shop Product Link"
            detectedJudol.isNotEmpty() -> "Situs Judi Online (Judol / Slot)"
            detectedPhishing.isNotEmpty() -> "Phishing / Social Engineering"
            detectedAdNetwork.isNotEmpty() -> "Ad Network Popup Redirect"
            else -> null
        }

        // Determine Risk Level & Safety Score
        val riskLevel: RiskLevel
        val safetyScore: Int
        val threatSummary: String
        val recommendations = mutableListOf<String>()

        when {
            detectedJudol.isNotEmpty() -> {
                riskLevel = RiskLevel.DANGER_JUDOL
                safetyScore = (10 - (detectedJudol.size * 2)).coerceAtLeast(0)
                threatSummary = "TERDETEKSI JUDI ONLINE (JUDOL)! Mengandung ${detectedJudol.size} kata kunci judi/slot berisiko tinggi."
                recommendations.add("JANGAN buka atau login di situs ini! Situs ini terindikasi kuat judi online ilegal.")
                recommendations.add("JANGAN pernah transfer atau mendaftarkan nomor HP / rekening bank.")
                recommendations.add("Laporkan URL ini ke Aduan Konten Kominfo / Satgas.")
            }
            detectedPhishing.isNotEmpty() -> {
                riskLevel = RiskLevel.DANGER_PHISHING
                safetyScore = 15
                threatSummary = "TERDETEKSI PHISHING & PENIPUAN! Pola iming-iming hadiah/bansos palsu."
                recommendations.add("Waspada pencurian data pribadi (OTP, Password, NIK, PIN Bank).")
                recommendations.add("Jangan memasukkan data akun WhatsApp, Telegram, atau e-Wallet.")
            }
            detectedAdNetwork.isNotEmpty() -> {
                riskLevel = RiskLevel.AD_TRACKER
                safetyScore = 40
                threatSummary = "TERDETEKSI POPUP IKLAN MENGGANGGU! Mengarahkan ke jaringan iklan agresif."
                recommendations.add("Gunakan pemblokir iklan (AdBlock) dan jangan izinkan notifikasi browser.")
                recommendations.add("Tutup tab segera jika muncul popup paksa download APK.")
            }
            isShopee || isTokopedia || isLazada || isTikTokShop -> {
                if (trackingFound.isNotEmpty()) {
                    riskLevel = RiskLevel.AD_TRACKER
                    safetyScore = 80
                    threatSummary = "Link $eComType dengan pelacak komisi/affiliate terpasang."
                    recommendations.add("Link aman untuk belanja, namun mengandung parameter komisi afiliasi.")
                    recommendations.add("Gunakan fitur 'Salin Link Bersih' di bawah untuk membuka produk murni tanpa pelacak.")
                } else {
                    riskLevel = RiskLevel.SAFE
                    safetyScore = 95
                    threatSummary = "Link resmi $eComType aman untuk diakses."
                    recommendations.add("Situs terverifikasi dan aman digunakan.")
                }
            }
            hops.size > 3 -> {
                riskLevel = RiskLevel.SUSPICIOUS
                safetyScore = 55
                threatSummary = "Redirect chain mencurigakan: URL dialihkan sebanyak ${hops.size} kali."
                recommendations.add("Waspada terhadap tujuan akhir yang disembunyikan pemendek link.")
            }
            !isSsl -> {
                riskLevel = RiskLevel.SUSPICIOUS
                safetyScore = 60
                threatSummary = "Koneksi tidak menggunakan enkripsi HTTPS aman (HTTP biasa)."
                recommendations.add("Hindari memasukkan informasi sensitif di situs tanpa SSL.")
            }
            else -> {
                riskLevel = RiskLevel.SAFE
                safetyScore = 98
                threatSummary = "Link bersih, aman, dan menggunakan sertifikat SSL terenkripsi."
                recommendations.add("Tidak ditemukan indikasi iklan popup jebakan, phishing, atau judol.")
            }
        }

        val allDetected = (detectedJudol + detectedPhishing + detectedAdNetwork).distinct()

        LinkReport(
            originalUrl = inputUrl,
            destinationUrl = finalUrl,
            domain = domain,
            riskLevel = riskLevel,
            safetyScore = safetyScore,
            threatSummary = threatSummary,
            detectedKeywords = allDetected,
            redirectHops = hops,
            trackingParamsFound = trackingFound,
            cleanedUrl = cleanedUrl,
            isSslSecure = isSsl,
            eComType = eComType,
            recommendations = recommendations
        )
    }

    private fun buildCleanUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            val builder = uri.buildUpon().clearQuery()
            uri.queryParameterNames?.forEach { name ->
                if (!TRACKING_PARAMS.contains(name.lowercase())) {
                    builder.appendQueryParameter(name, uri.getQueryParameter(name))
                }
            }
            builder.build().toString()
        } catch (e: Exception) {
            url.substringBefore("?")
        }
    }
}
