package com.example.data.model

enum class StockPlatform {
    SHUTTERSTOCK, ADOBE_STOCK, FREEPIK, GETTY_IMAGES
}

data class StockMetadata(
    val title: String = "",
    val description: String = "",
    val keywords: List<String> = emptyList(),
    val primaryCategory: String = "Technology",
    val secondaryCategory: String = "Business",
    val isEditorial: Boolean = false,
    val editorialReason: String = "",
    val shutterstockScore: Int = 95,
    val adobeStockScore: Int = 98,
    val freepikScore: Int = 92,
    val modelReleaseRequired: Boolean = false,
    val propertyReleaseRequired: Boolean = false,
    val visualStyle: String = "Realistic Photography / High Quality 4K"
)

enum class RiskLevel {
    SAFE,
    SUSPICIOUS,
    DANGER_JUDOL,
    DANGER_PHISHING,
    DANGER_MALWARE,
    AD_TRACKER
}

data class LinkReport(
    val originalUrl: String,
    val destinationUrl: String,
    val domain: String,
    val riskLevel: RiskLevel,
    val safetyScore: Int, // 0 - 100 (100 is cleanest)
    val threatSummary: String,
    val detectedKeywords: List<String> = emptyList(),
    val redirectHops: List<String> = emptyList(),
    val trackingParamsFound: Map<String, String> = emptyMap(),
    val cleanedUrl: String = "",
    val isSslSecure: Boolean = true,
    val eComType: String? = null, // "Shopee Affiliate", "Tokopedia Promo", "Judol Landing", etc.
    val recommendations: List<String> = emptyList()
)

enum class PlatformType {
    TIKTOK, INSTAGRAM, YOUTUBE, UNKNOWN
}

enum class DownloadState {
    IDLE, FETCHING_INFO, READY, DOWNLOADING, COMPLETED, FAILED
}

data class MediaFormatOption(
    val id: String,
    val label: String,
    val resolution: String,
    val format: String, // MP4 / MP3
    val estimatedSize: String,
    val directDownloadUrl: String,
    val isNoWatermark: Boolean = false
)

data class MediaItem(
    val id: String,
    val platform: PlatformType,
    val originalUrl: String,
    val title: String,
    val author: String,
    val durationText: String,
    val thumbnailUrl: String,
    val formats: List<MediaFormatOption> = emptyList(),
    val selectedFormatId: String = "",
    val downloadState: DownloadState = DownloadState.IDLE,
    val downloadProgress: Float = 0f,
    val localFilePath: String? = null,
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class ScriptSection(
    val timeCode: String,
    val sectionName: String,
    val voiceoverText: String,
    val visualPrompt: String,
    val onScreenText: String
)

data class ShortsScript(
    val title: String,
    val topic: String,
    val niche: String,
    val hooks: List<String>,
    val sections: List<ScriptSection>,
    val trendingHashtags: List<String>,
    val backgroundMusicVibe: String,
    val thumbnailConcept: String,
    val callToAction: String
)

enum class AudioBitrate(val kbps: Int, val label: String, val desc: String) {
    KBPS_320(320, "320 kbps", "Ultra HD / Studio Quality"),
    KBPS_256(256, "256 kbps", "High Fidelity (Recommended)"),
    KBPS_192(192, "192 kbps", "Standard Crystal Audio"),
    KBPS_128(128, "128 kbps", "Compact / Fast Download")
}

data class Mp3ConversionItem(
    val id: String,
    val youtubeUrl: String,
    val videoTitle: String,
    val artistName: String,
    val albumName: String,
    val genre: String,
    val durationText: String,
    val thumbnailUrl: String,
    val bitrate: AudioBitrate,
    val state: DownloadState = DownloadState.IDLE,
    val progress: Float = 0f,
    val localAudioPath: String? = null,
    val fileSizeFormatted: String = "",
    val audioDurationSeconds: Int = 180,
    val timestamp: Long = System.currentTimeMillis()
)
