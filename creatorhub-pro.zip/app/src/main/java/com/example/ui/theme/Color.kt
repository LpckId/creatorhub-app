package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand - Electric Indigo / Violet
val VioletPrimary = Color(0xFF7C3AED)
val VioletPrimaryDark = Color(0xFFA78BFA)
val VioletContainer = Color(0xFFEDE9FE)
val VioletContainerDark = Color(0xFF2E1065)

// Secondary Accent - Cyan
val CyanAccent = Color(0xFF06B6D4)
val CyanAccentDark = Color(0xFF22D3EE)
val CyanContainer = Color(0xFFCFFAFE)
val CyanContainerDark = Color(0xFF083344)

// Tertiary Accent - Rose / Amber
val CoralTertiary = Color(0xFFF43F5E)
val CoralTertiaryDark = Color(0xFFFB7185)
val EmeraldSuccess = Color(0xFF10B981)
val EmeraldSuccessDark = Color(0xFF34D399)
val AmberWarning = Color(0xFFF59E0B)
val AmberWarningDark = Color(0xFFFBBF24)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1F2937)
val DarkSurfaceCard = Color(0xFF1E293B)
val DarkOutline = Color(0xFF374151)
val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF9CA3AF)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightOutline = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
